package com.hit.lyx.dubbo.demo.api.entity;

public class Data {
    static DataGenerator data=new DataGenerator();
}
