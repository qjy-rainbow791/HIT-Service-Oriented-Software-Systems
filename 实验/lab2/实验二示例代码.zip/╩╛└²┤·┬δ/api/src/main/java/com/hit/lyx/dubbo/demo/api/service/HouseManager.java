package com.hit.lyx.dubbo.demo.api.service;

public interface HouseManager {
}
