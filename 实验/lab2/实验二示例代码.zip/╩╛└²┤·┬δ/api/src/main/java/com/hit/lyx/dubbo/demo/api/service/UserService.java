package com.hit.lyx.dubbo.demo.api.service;

import com.hit.lyx.dubbo.demo.api.entity.User;

public interface UserService {

    User getUser(Long id);
}
