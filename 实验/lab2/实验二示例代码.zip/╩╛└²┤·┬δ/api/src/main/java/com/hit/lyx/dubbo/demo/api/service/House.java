package com.hit.lyx.dubbo.demo.api.service;

public interface House {
    public int m();
}
