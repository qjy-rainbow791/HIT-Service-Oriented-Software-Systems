package com.hit.lyx.dubbo.demo.service;

import com.hit.lyx.dubbo.demo.api.service.HouseManager;

public class HouseManagerImpl implements HouseManager {
}
