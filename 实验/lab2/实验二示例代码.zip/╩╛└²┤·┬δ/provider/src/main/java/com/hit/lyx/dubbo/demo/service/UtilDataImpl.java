package com.hit.lyx.dubbo.demo.service;

import com.hit.lyx.dubbo.demo.api.service.UtilData;

public class UtilDataImpl implements UtilData {
}
