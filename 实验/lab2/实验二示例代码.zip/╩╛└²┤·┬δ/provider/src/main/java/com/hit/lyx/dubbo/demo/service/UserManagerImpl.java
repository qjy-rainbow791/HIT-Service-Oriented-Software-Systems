package com.hit.lyx.dubbo.demo.service;

import com.hit.lyx.dubbo.demo.api.service.UserManager;

public class UserManagerImpl implements UserManager {
}
