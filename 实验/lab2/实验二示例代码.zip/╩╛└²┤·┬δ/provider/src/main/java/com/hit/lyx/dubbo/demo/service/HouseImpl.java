package com.hit.lyx.dubbo.demo.service;

import com.hit.lyx.dubbo.demo.api.service.House;

public class HouseImpl implements House {
    public int m() {
        return 34;
    }
}
